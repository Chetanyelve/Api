import express from "express";

const router=express.Router();

const users=[
    {
        Company: "Samsung",
        device : "A10",
        Version : "Kitkat",
    },

    {
        Company: "MI Xaomi",
        device : "Note 5",
        Version : "Lolipop",
    },
];

router.get("/",(req, res) => {
    res.send(users);
});

router.post("/", (req, res) => {
    const user= req.body;

    users.push(user);
    res.send('Users with the name ${user.Company} added');

});
export default router;